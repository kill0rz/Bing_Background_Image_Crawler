Bing Hintergrundbild-Crawler v1.0 by kill0rz

Stand: 04.01.2015

+ Installation

Wir laden alle Dateien aus dem ZIP-Archiv hoch und geben den beiden Ordnern Schreibrechte.

+ Anwendung

Zum Aufrufen der Bilder wird t�glich die crawler.php (z.B. per Cronjob) aufgerufen. Die index.php gibt uns dann eine Gallerie der sich auf dem Server befindlichen Dateien zur�ck.

+ Lizenz

Der Crawler wurde unter kill0rz Unilicence v1.0 ver�ffentlicht. Diese liegt den Archiv bei.