<?php

// Bing Crawler v1.0 by kill0rz
// Version @ 04.01.2015

if(isset($_GET['getpic']) and file_exists("./pics/".trim($_GET['getpic']))){
	$filename = sprintf("%s/%s", "pics/", trim($_GET['getpic']));
	header("Content-Type: application/octet-stream");
	$save_as_name = basename("/pics/".trim($_GET['getpic']));
	header("Content-Disposition: attachment; filename=\"$save_as_name\"");
	readfile($filename);
}

if(!isset($_GET['pic']) or !file_exists("./pics/".trim($_GET['pic']))){
	echo "<meta http-equiv='refresh' content='0,URL=/' />";
}else{
	echo "<center><img height=80% src='./pics/{$_GET['pic']}' /><br><br><a href='download.php?getpic={$_GET['pic']}'>DOWNLOAD</a></center>";
}